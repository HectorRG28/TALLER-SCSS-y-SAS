

## ⚙️ Cómo Ejecutar el Proyecto

1.  Clona o descarga este repositorio.
2.  Necesitas un compilador de SASS para "traducir" los archivos SCSS a un único archivo CSS.
3.  Si usas Visual Studio Code, puedes instalar la extensión **"Live Sass Compiler, ya que la otra está deprecated(en desuso)"**.
4.  Una vez instalada, abre el archivo `main.scss` y haz clic en el botón **"Watch Sass"** que aparecerá en la barra inferior.
5.  Esto generará automáticamente el archivo `estilos.css` (o `main.css`) que está enlazado en el `index.html`.
6.  Abre el archivo `index.html` en tu navegador para ver el resultado.